<section>
  <div class="container content_wrap">
    <div class="row">
      <div class="footer_top_bg" style="background: url(&quot;<?php echo $webName ?>/img/logo/footer_top_bg.png&quot;) 0% 0% / cover no-repeat; height: 93px;"></div>
      <div class="col-md-4 col-sm-12">
        <ul class="footerList">
          <li><b> পরিকল্পনা ও বাস্তবায়নে:</b> </li>
          <hr>
          <li style="list-style: none;">মোহাম্মদ মোজাম্মেল হক</li>
          <li style="list-style: none;">প্রধান শিক্ষক</li>
          <li style="list-style: none;">ভাইঘাট উচ্চ বিদ্যালয়</li>
          </li>
        </ul>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12">

      </div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <ul>
          <li>
            <b> কারিগরি সহায়তায়:</b>
          </li>
          <hr>
          <li style="list-style: none;">
            <a target="_blank" href="https://api.whatsapp.com/send?phone=8801635355376&amp;text=I%27m%20interested%20in%20your%20services" style="text-decoration: none;">সাজ্জাদ হাসান রিয়াদ </a>
            </span>
          </li>
          <li style="list-style: none;">infinity developers</li>
        </ul>
      </div>
    </div>
  </div>
</section>