    <section>

      <header>
        <div class="container content_wrap">
          <div class="row">
            <div class="col-12">
              <a href="<?php echo $webName ?>/"><img src="<?php echo $webName ?>/img/header_img/img3.png" alt="" width="100%" /></a>
            </div>
          </div>
        </div>
      </header>
    </section>