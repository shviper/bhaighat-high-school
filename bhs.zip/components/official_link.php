<div class="headersidebar">
              <h1 class="fth">অফিসিয়াল লিঙ্ক</h1>
              <div class="important_link">
                <ul>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="http://www.moedu.gov.bd/"  target="_blank" style="color: #0693e3;"> শিক্ষা মন্ত্রণালয়</a>
                  </li>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="http://www.dshe.gov.bd/"  target="_blank" style="color: #0693e3;"> মাধ্যমিক ও উচ্চ শিক্ষা অধিদপ্তর</a>
                  </li>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="https://dhakaeducationboard.gov.bd/"  target="_blank" style="color: #0693e3;"> ঢাকা শিক্ষাবোর্ড</a>
                  </li>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="http://www.educationboardresults.gov.bd/" target="_blank" style="color: #0693e3;"> বোর্ড রেজাল্ট</a>
                  </li>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="http://www.banbeis.gov.bd/" target="_blank" style="color: #0693e3;"> ব্যানবেইজ</a>
                  </li>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="http://www.tangail.gov.bd/" target="_blank" style="color: #0693e3;"> টাঙ্গাইল জেলা</a>
                  </li>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="http://dhanbari.tangail.gov.bd/" target="_blank" style="color: #0693e3;"> ধনবাড়ী উপজেলা </a>
                  </li>
                  <li>
                    <i class="fas fa-arrow-circle-right" aria-hidden="true" style="color: #0693e3;"></i>
                    &nbsp;<a href="http://dhopakhaliup.tangail.gov.bd/" target="_blank" style="color: #0693e3;"> ধোপাখালী ইউনিয়ন </a>
                  </li>
                  
                </ul>
              </div>
            </div>