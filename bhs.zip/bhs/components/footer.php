<div class="footer">
    <div class="copyright">
        <p>
            © Designed &amp; by
            <a href="https://web.facebook.com/shviper" target="_blank">Sajjad Hasan Riyad</a> 2022
        </p>
    </div>
</div>